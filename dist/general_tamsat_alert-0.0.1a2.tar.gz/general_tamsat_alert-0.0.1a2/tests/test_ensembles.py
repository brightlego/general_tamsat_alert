import unittest
import src.general_tamsat_alert.ensembles as ensembles


class TestEnsembles(unittest.TestCase):
    def test_get_ensembles(self):
        self.assertEqual(True, False)  # add assertion here


if __name__ == "__main__":
    unittest.main()
